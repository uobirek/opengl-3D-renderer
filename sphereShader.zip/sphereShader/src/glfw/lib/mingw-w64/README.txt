GLFW static libs (32bit & 64bit) built by mingw-w64 for Windows
