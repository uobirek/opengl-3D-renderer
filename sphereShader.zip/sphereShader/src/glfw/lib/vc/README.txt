GLFW static lib for VisualStudio Universal CRT
