GLFW 64-bit lib for macOS universal binary (arm64 & x86_64)
